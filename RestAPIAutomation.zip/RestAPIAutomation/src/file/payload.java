package file;

public class payload {
	public static String getData() {
		return "{\"username\":\"rupeek\",\"password\":\"password\"}";
        		

	}
	
}