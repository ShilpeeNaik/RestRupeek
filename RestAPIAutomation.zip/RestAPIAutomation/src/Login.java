import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import org.testng.Assert;

import file.payload;
public class Login {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        RestAssured.baseURI="https://rahulshettyacademy.com";
        String response=given().log().all().
        body(payload.getData()).when().post("/maps/api/place/add/json?key=qaclick123").then().log().all().assertThat().statusCode(200).
        extract().response().toString();
       
}

}